export default function About() {
  return (
    <div>
      <h2>About Me</h2>
      <p>I am Manisha Apchunde, a passionate web developer with experience in React, JavaScript, and modern web technologies.</p>
    </div>
  );
}
