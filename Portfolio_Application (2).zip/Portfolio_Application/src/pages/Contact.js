export default function Contact() {
  return (
    <div>
      <h2>Contact</h2>
      <p>Email: manisha@example.com</p>
      <p>GitHub: github.com/manishaapchunde</p>
    </div>
  );
}
