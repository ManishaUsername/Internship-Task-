export default function Home() {
  return (
    <div>
      <h1>Welcome, I'm Manisha Apchunde</h1>
      <p>This is my professional portfolio website.</p>
    </div>
  );
}
