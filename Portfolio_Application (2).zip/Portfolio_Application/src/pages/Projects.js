export default function Projects() {
  return (
    <div>
      <h2>Projects</h2>
      <ul>
        <li>Portfolio Website using React</li>
        <li>Fake News Detection using BERT</li>
        <li>Leaf Disease Detection using TensorFlow</li>
      </ul>
    </div>
  );
}
