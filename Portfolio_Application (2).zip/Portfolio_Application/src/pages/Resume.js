export default function Resume() {
  return (
    <div>
      <h2>Resume</h2>
      <p>Click below to download my resume:</p>
      <a href="/resume.pdf" target="_blank" rel="noopener noreferrer">Download Resume</a>
    </div>
  );
}
